Para executar basta rodar $./TP1.py <Algoritmo> <entrada> PRINT (opcional).
É possivel também executar o script, bastar rodar um $chmod +x run.sh antes, depois apenas $./run.sh, 
este script vai rodar a entrada mais dificil do NPUZZEL.pdf, printando o caminho até chegar na solução e salvando a resposta em um arquivo <algoritimo>.out