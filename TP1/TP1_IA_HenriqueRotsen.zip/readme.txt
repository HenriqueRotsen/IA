Para executar basta rodar $./TP1.py <Algoritmo> <entrada> PRINT (opcional).
É possivel também executar o script, bastar rodar um $chmod +x run.sh antes, depois apenas $./run.sh, 
este script vai rodar, para todos os algoritmos, a entrada "8 0 2 5 7 3 1 4 6 PRINT", que possuí solução 15, salvando a resposta em um arquivo <algoritmo>.out